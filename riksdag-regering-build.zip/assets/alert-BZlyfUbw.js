import{c as e,e as a,Q as t}from"./index-BdZp_7kV.js";import{j as r}from"./ui-vendor-DdA1a0jp.js";import{r as s}from"./react-vendor-DwCPvY97.js";
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=e("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]),i=e("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]),l=t("relative w-full rounded-lg border p-4 [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground",{variants:{variant:{default:"bg-background text-foreground",destructive:"border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"}},defaultVariants:{variant:"default"}}),o=s.forwardRef(({className:e,variant:t,...s},d)=>r.jsx("div",{ref:d,role:"alert",className:a(l({variant:t}),e),...s}));
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */o.displayName="Alert";s.forwardRef(({className:e,...t},s)=>r.jsx("h5",{ref:s,className:a("mb-1 font-medium leading-none tracking-tight",e),...t})).displayName="AlertTitle";const n=s.forwardRef(({className:e,...t},s)=>r.jsx("div",{ref:s,className:a("text-sm [&_p]:leading-relaxed",e),...t}));n.displayName="AlertDescription";export{o as A,d as D,i as I,n as a};
