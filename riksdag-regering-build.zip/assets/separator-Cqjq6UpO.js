import{c as a,e}from"./index-BdZp_7kV.js";import{j as r,e as o}from"./ui-vendor-DdA1a0jp.js";import{r as t}from"./react-vendor-DwCPvY97.js";
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=a("CircleHelp",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]]),s=a("FilePen",[["path",{d:"M12.5 22H18a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v9.5",key:"1couwa"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M13.378 15.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",key:"1y4qbx"}]]),l=a("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]),n=a("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var d="horizontal",c=["horizontal","vertical"],p=t.forwardRef((a,e)=>{const{decorative:t,orientation:i=d,...s}=a,l=function(a){return c.includes(a)}(i)?i:d,n=t?{role:"none"}:{"aria-orientation":"vertical"===l?l:void 0,role:"separator"};return r.jsx(o.div,{"data-orientation":l,...n,...s,ref:e})});p.displayName="Separator";var h=p;const v=t.forwardRef(({className:a,orientation:o="horizontal",decorative:t=!0,...i},s)=>r.jsx(h,{ref:s,decorative:t,orientation:o,className:e("shrink-0 bg-border","horizontal"===o?"h-[1px] w-full":"h-full w-[1px]",a),...i}));v.displayName=h.displayName;export{i as C,s as F,n as M,v as S,l as a};
