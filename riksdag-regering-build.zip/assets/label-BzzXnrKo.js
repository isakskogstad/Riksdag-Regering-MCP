import{c as e,e as a,Q as s}from"./index-BdZp_7kV.js";import{j as t,e as r}from"./ui-vendor-DdA1a0jp.js";import{r as o}from"./react-vendor-DwCPvY97.js";
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=e("FileDown",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M12 18v-6",key:"17g6i2"}],["path",{d:"m9 15 3 3 3-3",key:"1npd3o"}]]);var d=o.forwardRef((e,a)=>t.jsx(r.label,{...e,ref:a,onMouseDown:a=>{var s;a.target.closest("button, input, select, textarea")||(null==(s=e.onMouseDown)||s.call(e,a),!a.defaultPrevented&&a.detail>1&&a.preventDefault())}}));d.displayName="Label";var n=d;const i=s("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),p=o.forwardRef(({className:e,...s},r)=>t.jsx(n,{ref:r,className:a(i(),e),...s}));p.displayName=n.displayName;export{l as F,p as L};
